document.addEventListener("DOMContentLoaded", function () {
    // Select all bookmark icons
    const bookmarks = document.querySelectorAll(".bookmark-icon");

    // Toggle active class on click
    bookmarks.forEach(bookmark => {
        bookmark.addEventListener("click", function () {
            this.classList.toggle("active");
        });
    });
});